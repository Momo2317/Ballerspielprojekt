package controller;

import java.awt.event.KeyEvent;
import gameobjects.GameObject;
import playground.SpaceInvadersLevel;

public class BreakoutController extends EgoController {

  public BreakoutController(double egoRad) {
    super(egoRad);
  }
  
  
  public void onUp(KeyEvent kc, GameObject ego) {
  }

  public void onDown(KeyEvent kc, GameObject ego) {
  }
  
  
  public void onSpace(KeyEvent kc, GameObject ego) {    
  }
  
  
  
  

}
