import playground.BossLevel;
import playground.BreakoutLevel3;
import playground.Level1;
import playground.Level2;
import playground.Level3;
import playground.Playground;

public class Prog2Game extends GameLoop {
	
	public static void main(String[] args) {
		Prog2Game p2g = new Prog2Game();
		p2g.runGame(args);
	}

	@Override
	public void defineLevels() {
		this.levels = new Playground[11];
		this.levels[0] = new Level1();
		this.levels[1] = new Level2();
		this.levels[1] = new Level3();
		this.levels[3] = new BreakoutLevel3();
		this.levels[4] = new BossLevel();
	}
	
	
}
 