package playground;

import java.awt.Color;

import gameobjects.GameObject;
import gameobjects.TextObject;

public class BreakoutLevel3 extends BreakoutLevel2 {
	TextObject to;
	TextObject lo;
	
	@Override
	public void prepareLevel(String level) {
		super.prepareLevel(level);
		this.getOrCreateGlobalFlag("points", Integer.valueOf(0));
		to = new TextObject("punkteAnzeige", this, 600, 10, 0, 0, getGlobalFlag("points").toString(), 10, Color.RED);
		addObject(to);
		
		this.getOrCreateGlobalFlag("lives", Integer.valueOf(3));
		lo = new TextObject("lebenAnzeige", this, 600, 550, 0, 0, getGlobalFlag("lives").toString(), 10, Color.GREEN);
		addObject(lo);
	}
	
	@Override
	public void actionIfBallHitsBrick(GameObject ball, GameObject brick) {
		super.actionIfBallHitsBrick(ball, brick);
		this.setGlobalFlag("points", (Integer)getGlobalFlag("points") + 10);
		to.setText(getGlobalFlag("points").toString());
	}
	
	@Override
	public void applyGameLogic() {
		super.applyGameLogic();
		if(this.ball.getY() > this.ego.getY()) {
			this.setGlobalFlag("lives", (Integer)getGlobalFlag("lives") - 1);
			lo.setText(getGlobalFlag("lives").toString());
			this.ball.setY(this.ego.getY()-10.0);
			this.ball.setX(this.ego.getX());
		}
	}
	
	@Override
	public boolean gameOver() {
		if(this.getGlobalFlag("lives").equals(Integer.valueOf(-1))) {
			return true;
		}
		return false;
	}

	
}
//getGlobalFlag("points").toString()
//getOrCreateGlobalFlag("points", Integer.valueOf(0)).toString()
