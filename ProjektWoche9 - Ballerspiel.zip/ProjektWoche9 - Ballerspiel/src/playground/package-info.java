/**
 * The package playground contains all classes implementing and describing game levels. Main class
 * to be subclassed here: {@link playground.Playground}. A notable sublass that is already
 * implelented is {@link playground.SpaceInvadersLevel}, showing an example of how to subclass
 * {@link playground.Playground},
 */
package playground;
