/**
 * Contains the executable classes of this game. If you subclass {@link GameLoop}, put the
 * subclasses here.
 */
